#!/bin/bash
cd /home2/jcjeong/project/stanalyzer0/stanalyzer/static/analyzers
/export/apps/bin/python2.7 thickness_carbon.py /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/20130716133121871146zdDzT0/para 0
