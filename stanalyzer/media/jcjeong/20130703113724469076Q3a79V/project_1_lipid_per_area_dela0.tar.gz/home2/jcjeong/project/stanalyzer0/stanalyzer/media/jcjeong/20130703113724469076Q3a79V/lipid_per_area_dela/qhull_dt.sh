#!/bin/bash
/home2/jcjeong/project/qhull/qhull-2012.1/bin/qdelaunay i < /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/20130703113724469076Q3a79V/lipid_per_area_dela/dt_crd.dat > /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/20130703113724469076Q3a79V/lipid_per_area_dela/dt_rgn.dat
