#!/bin/bash
cd /home2/jcjeong/project/stanalyzer0/stanalyzer/static/analyzers
/home/sunhwan/local/python/bin/python rmsd.py /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/201306031414594993654l7hwq/para 0
