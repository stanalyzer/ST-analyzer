#!/bin/bash
cd /home2/jcjeong/project/stanalyzer0/stanalyzer/static/analyzers
/export/apps/bin/python2.7 sterol_tilt_tail.py /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/20130718141250144697wrSElg/para 0
