#!/bin/bash
/home2/jcjeong/project/qhull/qhull-2012.1/bin/qvoronoi p < /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/20130709091649157378Vm27Lj/lipid_per_area_voro/crd.dat > /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/20130709091649157378Vm27Lj/lipid_per_area_voro/vtx.dat
/home2/jcjeong/project/qhull/qhull-2012.1/bin/qvoronoi FN < /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/20130709091649157378Vm27Lj/lipid_per_area_voro/crd.dat > /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/20130709091649157378Vm27Lj/lipid_per_area_voro/rgn.dat
