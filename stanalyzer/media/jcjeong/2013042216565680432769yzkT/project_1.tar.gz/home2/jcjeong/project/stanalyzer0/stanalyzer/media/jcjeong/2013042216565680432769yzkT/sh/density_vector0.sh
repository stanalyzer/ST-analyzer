#!/bin/bash
cd /home2/jcjeong/project/stanalyzer0/stanalyzer/static/analyzers
/home/sunhwan/local/python/bin/python density_vector.py /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/2013042216565680432769yzkT/para 0
