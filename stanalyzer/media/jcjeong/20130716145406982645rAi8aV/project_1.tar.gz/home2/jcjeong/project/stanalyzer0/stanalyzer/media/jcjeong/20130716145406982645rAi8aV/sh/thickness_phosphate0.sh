#!/bin/bash
cd /home2/jcjeong/project/stanalyzer0/stanalyzer/static/analyzers
/export/apps/bin/python2.7 thickness_phosphate.py /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/20130716145406982645rAi8aV/para 0
