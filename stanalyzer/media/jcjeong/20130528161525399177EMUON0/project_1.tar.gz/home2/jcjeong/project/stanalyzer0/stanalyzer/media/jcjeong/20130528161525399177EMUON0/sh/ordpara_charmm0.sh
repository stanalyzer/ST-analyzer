#!/bin/bash
cd /home2/jcjeong/project/stanalyzer0/stanalyzer/static/analyzers
/home/sunhwan/local/python/bin/python ordpara_charmm.py /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/20130528161525399177EMUON0/para 0
