#!/bin/bash
cd /home2/jcjeong/project/stanalyzer0/stanalyzer/static/analyzers
/home/sunhwan/local/python/bin/python helix_tilt.py /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/201302201658597766065UEKQ7/para 0
