#!/bin/bash
cd /home2/jcjeong/project/stanalyzer0/stanalyzer/static/analyzers
/home/sunhwan/local/python/bin/python box.py /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/201302150937197461706nOtvG/para 0
