#!/bin/bash
cd /home2/jcjeong/project/stanalyzer0/stanalyzer/static/analyzers
/home/sunhwan/local/python/bin/python box.py /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/20130227141032563403BTEBF6/para 0
