#!/bin/bash
cd /home2/jcjeong/project/stanalyzer0/stanalyzer/static/analyzers
/home/sunhwan/local/python/bin/python helix_tilt.py /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/20130215093652750891EyevkZ/para 1
