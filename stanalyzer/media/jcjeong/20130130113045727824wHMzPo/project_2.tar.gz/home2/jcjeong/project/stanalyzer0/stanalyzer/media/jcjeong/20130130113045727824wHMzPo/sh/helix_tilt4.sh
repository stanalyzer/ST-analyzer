#!/bin/bash
cd /home2/jcjeong/project/stanalyzer0/stanalyzer/static/analyzers
/home/sunhwan/local/python/bin/python helix_tilt.py /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/20130130113045727824wHMzPo/para 4
