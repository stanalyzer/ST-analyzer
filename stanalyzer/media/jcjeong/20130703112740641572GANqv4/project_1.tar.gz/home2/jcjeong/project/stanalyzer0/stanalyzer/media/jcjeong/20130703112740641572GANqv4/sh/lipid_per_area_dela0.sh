#!/bin/bash
cd /home2/jcjeong/project/stanalyzer0/stanalyzer/static/analyzers
/home/sunhwan/local/python/bin/python lipid_per_area_dela.py /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/20130703112740641572GANqv4/para 0
