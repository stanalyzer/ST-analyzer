#!/bin/bash
cd /home2/jcjeong/project/stanalyzer0/stanalyzer/static/analyzers
/home/sunhwan/local/python/bin/python ordpara_dopc.py /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/20130502125558102291gHffZL/para 0
