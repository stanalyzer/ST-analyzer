#!/bin/bash
cd /home2/jcjeong/project/stanalyzer0/stanalyzer/static/analyzers
/export/apps/bin/python2.7 thickness_carbon.py /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/20130716143503073435YX1twW/para 0
