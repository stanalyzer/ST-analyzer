#!/bin/bash
/home2/jcjeong/project/qhull/qhull-2012.1/bin/qdelaunay i < /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/201307031131268476128b6vFi/lipid_per_area_dela/dt_crd.dat > /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/201307031131268476128b6vFi/lipid_per_area_dela/dt_rgn.dat
