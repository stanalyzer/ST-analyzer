#!/bin/bash
cd /home2/jcjeong/project/stanalyzer0/stanalyzer/static/analyzers
/export/apps/bin/python2.7 density_lpT.py /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/20130716160123794979tpuRvc/para 0
