#!/bin/bash
cd /home2/jcjeong/project/stanalyzer0/stanalyzer/static/analyzers
/home/sunhwan/local/python/bin/python ordpara_charmm.py /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/20130529110737163717h6lYEP/para 2
