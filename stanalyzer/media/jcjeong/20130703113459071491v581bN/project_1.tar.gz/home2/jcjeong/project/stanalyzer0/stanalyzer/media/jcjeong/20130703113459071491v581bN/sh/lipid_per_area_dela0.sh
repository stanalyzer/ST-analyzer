#!/bin/bash
cd /home2/jcjeong/project/stanalyzer0/stanalyzer/static/analyzers
/home/sunhwan/local/python/bin/python lipid_per_area_dela.py /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/20130703113459071491v581bN/para 0
