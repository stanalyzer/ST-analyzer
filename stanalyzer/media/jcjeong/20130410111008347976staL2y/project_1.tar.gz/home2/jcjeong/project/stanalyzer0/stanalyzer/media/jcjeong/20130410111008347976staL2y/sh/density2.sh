#!/bin/bash
cd /home2/jcjeong/project/stanalyzer0/stanalyzer/static/analyzers
/home/sunhwan/local/python/bin/python density.py /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/20130410111008347976staL2y/para 2
