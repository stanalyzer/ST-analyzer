#!/bin/bash
cd /home2/jcjeong/project/stanalyzer0/stanalyzer/static/analyzers
/home/sunhwan/local/python/bin/python ordpara_dopc.py /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/201305011631168971809CRDea/para 0
