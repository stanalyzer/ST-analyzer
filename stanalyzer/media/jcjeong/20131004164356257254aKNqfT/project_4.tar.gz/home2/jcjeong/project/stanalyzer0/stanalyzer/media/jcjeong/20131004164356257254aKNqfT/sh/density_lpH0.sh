#!/bin/bash
cd /home2/jcjeong/project/stanalyzer0/stanalyzer/static/analyzers
/export/apps/bin/python2.7 density_lpH.py /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/20131004164356257254aKNqfT/para 0
