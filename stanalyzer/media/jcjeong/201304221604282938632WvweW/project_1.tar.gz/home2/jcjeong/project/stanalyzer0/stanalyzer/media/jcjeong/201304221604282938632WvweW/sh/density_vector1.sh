#!/bin/bash
cd /home2/jcjeong/project/stanalyzer0/stanalyzer/static/analyzers
/home/sunhwan/local/python/bin/python density_vector.py /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/201304221604282938632WvweW/para 1
