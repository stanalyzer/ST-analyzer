#!/bin/bash
cd /home2/jcjeong/project/stanalyzer0/stanalyzer/static/analyzers
/export/apps/bin/python2.7 lipid_per_area_voro.py /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/20130715150803971344K4rjWL/para 0
