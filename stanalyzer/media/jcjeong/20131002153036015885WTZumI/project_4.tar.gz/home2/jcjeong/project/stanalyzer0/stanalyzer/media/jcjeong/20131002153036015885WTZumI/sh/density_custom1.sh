#!/bin/bash
cd /home2/jcjeong/project/stanalyzer0/stanalyzer/static/analyzers
/export/apps/bin/python2.7 density_custom.py /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/20131002153036015885WTZumI/para 1
