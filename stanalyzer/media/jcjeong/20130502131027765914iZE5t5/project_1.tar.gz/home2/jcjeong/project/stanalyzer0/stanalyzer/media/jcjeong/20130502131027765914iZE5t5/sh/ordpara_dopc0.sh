#!/bin/bash
cd /home2/jcjeong/project/stanalyzer0/stanalyzer/static/analyzers
/home/sunhwan/local/python/bin/python ordpara_dopc.py /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/20130502131027765914iZE5t5/para 0
