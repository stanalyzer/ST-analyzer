#!/bin/bash
cd /home2/jcjeong/project/stanalyzer0/stanalyzer/static/analyzers
/export/apps/bin/python2.7 rmsd.py /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/201308011021147457862lIS6m/para 0
