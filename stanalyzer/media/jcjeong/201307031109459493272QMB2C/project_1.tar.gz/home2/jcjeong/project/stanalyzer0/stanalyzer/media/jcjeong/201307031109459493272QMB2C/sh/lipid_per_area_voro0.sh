#!/bin/bash
cd /home2/jcjeong/project/stanalyzer0/stanalyzer/static/analyzers
/home/sunhwan/local/python/bin/python lipid_per_area_voro.py /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/201307031109459493272QMB2C/para 0
