#!/bin/bash
cd /home2/jcjeong/project/stanalyzer0/stanalyzer/static/analyzers
/export/apps/bin/python2.7 ordpara_charmm.py /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/201307181517130444484eOOTa/para 0
