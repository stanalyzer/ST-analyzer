#!/bin/bash
cd /home2/jcjeong/project/stanalyzer0/stanalyzer/static/analyzers
/home/sunhwan/local/python/bin/python ordpara_charmm.py /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/201305281613223173662pGQ9v/para 0
