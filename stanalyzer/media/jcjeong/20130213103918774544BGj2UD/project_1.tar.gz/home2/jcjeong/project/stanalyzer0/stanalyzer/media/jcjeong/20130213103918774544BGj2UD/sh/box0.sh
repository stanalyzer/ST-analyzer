#!/bin/bash
cd /home2/jcjeong/project/stanalyzer0/stanalyzer/static/analyzers
/home/sunhwan/local/python/bin/python box.py /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/20130213103918774544BGj2UD/para 0
