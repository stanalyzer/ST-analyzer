#!/bin/bash
/home2/jcjeong/project/qhull/qhull-2012.1/bin/qvoronoi p < /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/20130703111832029648VUG3g8/lipid_per_area_voro/crd.dat > /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/20130703111832029648VUG3g8/lipid_per_area_voro/vtx.dat
/home2/jcjeong/project/qhull/qhull-2012.1/bin/qvoronoi FN < /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/20130703111832029648VUG3g8/lipid_per_area_voro/crd.dat > /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/20130703111832029648VUG3g8/lipid_per_area_voro/rgn.dat
