#!/bin/bash
cd /home2/jcjeong/project/stanalyzer0/stanalyzer/static/analyzers
/home/sunhwan/local/python/bin/python ordpara_dopc.py /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/201305021302046449643Ifn6T/para 0
