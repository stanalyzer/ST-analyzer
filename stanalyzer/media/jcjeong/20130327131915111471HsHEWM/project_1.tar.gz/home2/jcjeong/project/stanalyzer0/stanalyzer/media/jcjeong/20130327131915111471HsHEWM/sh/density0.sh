#!/bin/bash
cd /home2/jcjeong/project/stanalyzer0/stanalyzer/static/analyzers
/home/sunhwan/local/python/bin/python density.py /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/20130327131915111471HsHEWM/para 0
