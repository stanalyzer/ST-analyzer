#!/bin/bash
cd /home2/jcjeong/project/stanalyzer0/stanalyzer/static/analyzers
/export/apps/bin/python2.7 lipid_per_area_voro.py /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/20130801171210963098E7p7I0/para 0
