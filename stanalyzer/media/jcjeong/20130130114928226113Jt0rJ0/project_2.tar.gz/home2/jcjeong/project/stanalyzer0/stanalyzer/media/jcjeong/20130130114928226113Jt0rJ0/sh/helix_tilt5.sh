#!/bin/bash
cd /home2/jcjeong/project/stanalyzer0/stanalyzer/static/analyzers
/home/sunhwan/local/python/bin/python helix_tilt.py /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/20130130114928226113Jt0rJ0/para 5
