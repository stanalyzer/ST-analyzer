#!/bin/bash
cd /home2/jcjeong/project/stanalyzer0/stanalyzer/static/analyzers
/export/apps/bin/python2.7 thickness_phosphate.py /home2/jcjeong/project/stanalyzer0/stanalyzer/media/jcjeong/20130801165252936336C0HKYW/para 0
